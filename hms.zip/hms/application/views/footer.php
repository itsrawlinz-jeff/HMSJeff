    <div style="clear:both;color:#aaa; padding:20px;">

    	<hr /><center>&copy; 2013 <a target="_blank" href="http://optimumlinkup.com.ng">Optimum Linkup Computer Institute</a></center>

    </div>